package com.example.enviarobjetosparcelables;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Date;

public class Contacto implements Parcelable {
    String mNombre;
    ArrayList<Contacto> mFamiliares;
    String mTelefono;
    int mNumeroHijos;
    Date mFechaNacimiento;
    boolean mCasado;
    Contacto(String Nombre, String Telefono, int nHijos, Date fecha, boolean Casado){
        mNombre=Nombre;
        mTelefono=Telefono;
        mNumeroHijos=nHijos;
        mCasado=Casado;
        mFechaNacimiento=fecha;
        mFamiliares=new ArrayList<Contacto>();
    }

    protected Contacto(Parcel in) {
        mNombre = in.readString();
        mFamiliares = in.createTypedArrayList(Contacto.CREATOR);
        mTelefono = in.readString();
        mNumeroHijos = in.readInt();
        mCasado = in.readByte() != 0;
    }

    public static final Creator<Contacto> CREATOR = new Creator<Contacto>() {
        @Override
        public Contacto createFromParcel(Parcel in) {
            return new Contacto(in);
        }

        @Override
        public Contacto[] newArray(int size) {
            return new Contacto[size];
        }
    };

    void addFamiliar(Contacto c){
        mFamiliares.add(c);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel parcel, int i) {
        parcel.writeString(mNombre);
        parcel.writeTypedList(mFamiliares);
        parcel.writeString(mTelefono);
        parcel.writeInt(mNumeroHijos);
        parcel.writeByte((byte) (mCasado ? 1 : 0));
    }
}
