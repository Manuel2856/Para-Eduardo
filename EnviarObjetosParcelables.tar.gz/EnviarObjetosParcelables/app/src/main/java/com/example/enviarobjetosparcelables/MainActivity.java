package com.example.enviarobjetosparcelables;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Contacto a;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b = (Button) findViewById(R.id.button);
        SimpleDateFormat simpeDateFormat = new SimpleDateFormat("dd/M/yyyy");
        try {
            a = new Contacto("Pedro Pérez", "555696677", 2, simpeDateFormat.parse("25/10/1997"),false);
            a.addFamiliar((new Contacto("Elena Pérez", "555696677", 0, simpeDateFormat.parse("20/1/1997"),false)));

        } catch (ParseException e) {
            System.out.println("Error en el formato de fecha");
        }
        TextView t = findViewById(R.id.textView);
        t.setText("Vamos a enviar los datos de " + a.mNombre);
        b.setOnClickListener(this::onClick);
    }
    public void onClick(View v){
        Intent i = new Intent(this, ActivityB.class);
        i.putExtra("pedro",a);
        startActivity(i);
    }
}