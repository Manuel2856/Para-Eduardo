package com.example.enviarobjetosparcelables;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityB extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);

        TextView t = findViewById(R.id.textView2);
        Contacto c = (Contacto) getIntent().getParcelableExtra("pedro");
        t.setText(c.mNombre+ " " + c.mTelefono);
    }
}
